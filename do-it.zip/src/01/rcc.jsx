import React, { Component } from 'react';

class rcc extends Component {
  render() {
    var text = '따움표';
    return <div></div>;
  }
}

export default rcc;
