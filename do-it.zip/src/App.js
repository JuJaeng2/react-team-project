import React, { useState, useEffect } from 'react';
import Login from './Login';
import MyPage from './MyPage';

const App = (props) => {
  const [isLogin, setIsLogin] = useState(false);
  const [userData, setUserData] = useState(null);

  const loginHandler = () => {
    setIsLogin(true);
  };

  const setUserInfo = (object) => {
    setUserData(object);
  };

  useEffect(() => {
    isLogin &&
      setTimeout(() => {
        setUserInfo({ userId: 'gildong', email: 'gdhong@naver.com' });
      }, 4000);
  }, [isLogin]);

  return (
    <div>{isLogin ? <MyPage userData={userData} /> : <Login loginHandler={loginHandler} />}</div>
  );
};

export default App;
